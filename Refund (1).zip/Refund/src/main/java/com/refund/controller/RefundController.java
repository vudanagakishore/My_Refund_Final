package com.refund.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.refund.service.ReturnService;

@CrossOrigin(origins = "*")
@RestController
public class RefundController {

	@Autowired
	ReturnService returnservice;

	
	/*
	 * Sampath Refund Amount
	 */
	@CrossOrigin
	@GetMapping("/refundamount/{id}")
	public double refundamount(@PathVariable String id) {
		return returnservice.refundamount(id);
	}

}
