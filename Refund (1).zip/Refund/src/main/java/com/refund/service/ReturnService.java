package com.refund.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.refund.dao.ReturnDao;
import com.refund.entity.Return;

@Service
public class ReturnService {

	/*
	 * Autowiring with Repository
	 */
	@Autowired
	private ReturnDao returndao;

	Return returnp;

	/*
	 * Sampath Refund Amount
	 */
	public double refundamount(String id) {
		returnp = new Return("PROD_00001", 1000, "credit", 200);
		returndao.save(returnp);
		returnp = new Return("PROD_00002", 500, "netbanking", 200);
		returndao.save(returnp);
		returnp = new Return("PROD_00003", 600, "netbanking", 200);
		returndao.save(returnp);
		returnp = new Return("PROD_00004", 100, "credit", 200);
		returndao.save(returnp);
		return returndao.findById(id).get().getPrice();
	}
	
	
//	public List<Return> addOrder(Return returnp)
//	{
//		float reamount = (float) returnp.getPrice();
//		String s1 = "credit";
//		String s2 = "netbanking";
//		if(returnp.getPaymentMode().contains(s1))
//		{
//			String s = "You Amount is refunded in to your "+ returnp.getPaymentMode();
//			returnp.setStatement(s);
//			float no = (float) returnp.getWalletBalance();
//			returnp.setWalletBalance(returnp.getWalletBalance()+reamount);
//			returnp.setAfterRefundBalance("Befor Your Amount is "+no + "..........After refund your Amount " + returnp.getWalletBalance());
//		}
//		
//		else if (returnp.getPaymentMode()==s2)
//		{
//			
//			String s = "You Amount is refunded in to your "+ returnp.getPaymentMode();
//			returnp.setStatement(s);
//			float no = (float) returnp.getWalletBalance();
//			returnp.setWalletBalance(returnp.getWalletBalance()+reamount);
//			returnp.setAfterRefundBalance("Befor Your Amount is "+no + "..........After refund your Amount " + returnp.getWalletBalance());
//		}
//		
//		else
//		{
//			String s = "You Amount is wil be return to your hand by  "+ returnp.getPaymentMode();
//			returnp.setStatement(s);
//			returnp.setWalletBalance(returnp.getWalletBalance()+reamount);
//			returnp.setAfterRefundBalance("After refund your Amount " + returnp.getWalletBalance());
//		}
//		returndao.save(returnp);
//		return returndao.findAll();
//	}

}
