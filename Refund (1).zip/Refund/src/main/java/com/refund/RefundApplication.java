package com.refund;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefundApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefundApplication.class, args);
	}

}
