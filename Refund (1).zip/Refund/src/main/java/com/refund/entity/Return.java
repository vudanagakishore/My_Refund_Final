package com.refund.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "productReturn")
public class Return {
	@Id
	private String prodId;

	private double price;

	private String paymentMode;

	private double walletBalance = 200;

	/**
	 * 
	 */
	public Return() {
		super();
	}

	/**
	 * @param prodId
	 * @param price
	 * @param paymentMode
	 * @param walletBalance
	 */
	public Return(String prodId, double price, String paymentMode, double walletBalance) {
		super();
		this.prodId = prodId;
		this.price = price;
		this.paymentMode = paymentMode;
		this.walletBalance = walletBalance;
	}

	/**
	 * @return the prodId
	 */
	public String getProdId() {
		return prodId;
	}

	/**
	 * @param prodId the prodId to set
	 */
	public void setProdId(String prodId) {
		this.prodId = prodId;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * @return the paymentMode
	 */
	public String getPaymentMode() {
		return paymentMode;
	}

	/**
	 * @param paymentMode the paymentMode to set
	 */
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	/**
	 * @return the walletBalance
	 */
	public double getWalletBalance() {
		return walletBalance;
	}

	/**
	 * @param walletBalance the walletBalance to set
	 */
	public void setWalletBalance(double walletBalance) {
		this.walletBalance = walletBalance;
	}

	@Override
	public String toString() {
		return "Return [prodId=" + prodId + ", price=" + price + ", paymentMode=" + paymentMode + ", walletBalance="
				+ walletBalance + "]";
	}

}
